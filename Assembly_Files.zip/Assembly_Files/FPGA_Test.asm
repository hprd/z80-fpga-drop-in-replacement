
 ORG 0000h

        LD A, 0Fh        ; start from 5 (you can change this)

LOOP:
        OUT (01h), A     ; output current value
        DEC A            ; decrement A
        JP LOOP          ; infinite loop
