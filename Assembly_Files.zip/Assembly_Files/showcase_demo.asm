        ORG 0000h

; =====================================================
; POWER-UP DELAY (~60ms-ish, 3× slower than before)
; =====================================================
        LD B,120
PWR0:   LD C,255
PWR1:   DEC C
        JR NZ,PWR1
        DJNZ PWR0

; =====================================================
; INIT LCD (UNCHANGED LOGIC, SLOWER TIMING)
; =====================================================

        LD A,030h
        OUT (0),A
        LD B,120
D0:     LD C,255
D1:     DEC C
        JR NZ,D1
        DJNZ D0

        LD A,030h
        OUT (0),A
        LD B,60
D2:     LD C,255
D3:     DEC C
        JR NZ,D3
        DJNZ D2

        LD A,030h
        OUT (0),A
        LD B,60
D4:     LD C,255
D5:     DEC C
        JR NZ,D5
        DJNZ D4

        LD A,020h
        OUT (0),A
        LD B,60
D6:     LD C,255
D7:     DEC C
        JR NZ,D7
        DJNZ D6

; Function set (0x28)
        LD A,028h
        OUT (0),A
        LD A,028h
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,60
F1:     LD C,255
F2:     DEC C
        JR NZ,F2
        DJNZ F1

; Display ON (0x0C)
        LD A,00Ch
        OUT (0),A
        LD A,00Ch
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,60
D8:     LD C,255
D9:     DEC C
        JR NZ,D9
        DJNZ D8

; Entry mode (0x06)
        LD A,006h
        OUT (0),A
        LD A,006h
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,60
D10:    LD C,255
D11:    DEC C
        JR NZ,D11
        DJNZ D10

; =====================================================
; MAIN LOOP
; =====================================================

MAIN:

; -------- CLEAR DISPLAY --------
        LD A,001h
        OUT (0),A
        LD A,001h
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,120
CL0:    LD C,255
CL1:    DEC C
        JR NZ,CL1
        DJNZ CL0

; -------- SET CURSOR (0x90) --------
        LD A,090h
        OUT (0),A
        LD A,090h
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,60
S1:     LD C,255
S2:     DEC C
        JR NZ,S2
        DJNZ S1

; -------- PRINT "HELLO WORLD!" --------

; H
        LD A,'H'
        OUT (8),A
        LD A,'H'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
H1:     LD C,255
H2:     DEC C
        JR NZ,H2
        DJNZ H1

; E
        LD A,'E'
        OUT (8),A
        LD A,'E'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
E1:     LD C,255
E2:     DEC C
        JR NZ,E2
        DJNZ E1

; L
        LD A,'L'
        OUT (8),A
        LD A,'L'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
L1:     LD C,255
L2:     DEC C
        JR NZ,L2
        DJNZ L1

; L
        LD A,'L'
        OUT (8),A
        LD A,'L'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
L3:     LD C,255
L4:     DEC C
        JR NZ,L4
        DJNZ L3

; O
        LD A,'O'
        OUT (8),A
        LD A,'O'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
O1:     LD C,255
O2:     DEC C
        JR NZ,O2
        DJNZ O1

; space
        LD A,' '
        OUT (8),A
        LD A,' '
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
SP1:    LD C,255
SP2:    DEC C
        JR NZ,SP2
        DJNZ SP1

; W
        LD A,'W'
        OUT (8),A
        LD A,'W'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
W1:     LD C,255
W2:     DEC C
        JR NZ,W2
        DJNZ W1

; O
        LD A,'O'
        OUT (8),A
        LD A,'O'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
WO1:    LD C,255
WO2:    DEC C
        JR NZ,WO2
        DJNZ WO1

; R
        LD A,'R'
        OUT (8),A
        LD A,'R'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
R1:     LD C,255
R2:     DEC C
        JR NZ,R2
        DJNZ R1

; L
        LD A,'L'
        OUT (8),A
        LD A,'L'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
WL1:    LD C,255
WL2:    DEC C
        JR NZ,WL2
        DJNZ WL1

; D
        LD A,'D'
        OUT (8),A
        LD A,'D'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
D12:    LD C,255
D13:    DEC C
        JR NZ,D13
        DJNZ D12

; !
        LD A,'!'
        OUT (8),A
        LD A,'!'
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (8),A

        LD B,60
EX1:    LD C,255
EX2:    DEC C
        JR NZ,EX2
        DJNZ EX1

; -------- SCROLL LEFT --------
        LD B,16
SCR1:
        LD A,018h
        OUT (0),A
        LD A,018h
        RLCA
        RLCA
        RLCA
        RLCA
        OUT (0),A

        LD B,75
SC1:    LD C,255
SC2:    DEC C
        JR NZ,SC2
        DJNZ SC1

        DJNZ SCR1

        JP MAIN