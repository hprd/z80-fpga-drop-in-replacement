        ORG 0000h

START:  LD A, 01h        ; Start with bit 0 set (00000001)

LOOP:   OUT (01h), A     ; Send A to I/O port 01h
        RLCA             ; Rotate A left, bit 7 -> bit 0
        JP LOOP          ; Repeat forever