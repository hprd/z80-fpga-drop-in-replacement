`timescale 1ns / 1ps

//8-BIT LOAD GROUP
`define LD_r_n pla[17] & ~pla[50] //Immediate register load of register R with 8-bit value N

//8-BIT LOAD Memory
`define LD_hl_r pla[59] & ~use_ixiy

//JUMP GROUP
`define JP_cc_nn pla[43] //Conditional Jump based on CC conditions to address NN
`define JP_nn pla[29]   // Unconditional Jump to address NN
`define JR_ss_e pla[48] //Conditional Jump based on conditions to e. Used for:   JR NZ,  e   JR Z, e   JR NC, e   JR C, e - specific condition found in opcode[4:3]
`define DJNZ_e pla[26] //Conditional Jump, register value B determines branching


//8-BIT ARITHMETIC GROUP
`define ALU_A_r pla[65] & ~pla[52] //ALU Operation with Accumulator and register R

`define CP_OP pla[76]   //ALU Operation is CP
`define SUB_OP pla[78] //ALU Operation is SUB
`define SBC_OP pla[79] //ALU Operation is SBC
`define ADC_OP pla[80] //ALU Operation is ADC
`define ADD_OP pla[84] //ALU Operation is ADD
`define AND_OP pla[85] //ALU Operation is AND
`define OR_OP pla[86] //ALU Operation is OR
`define XOR_OP pla[88] //ALU Operation is XOR

`define DEC_r pla[75] & ~pla[53]        //DEC Operation on a register
`define DEC_hl pla[53] & ~use_ixiy      //DEC on HL register
//`define DEC_ixiy pla[53] & useixiy      //DEC on IX+d or IY+d
//`define DEC_OP pla[75]                  //AALU operation is DEC

//INPUT AND OUTPUT GROUPS
`define OUT_n_A pla[37] & pla[28] //Outputs data A to peripheral on I/O Address n

//ROTATE GROUP
`define ROTATE_A pla[25] //Handles RLCA,RLA,RRCA,RRA

`define RLCA opcode == 8'h07 // Specific Opcode for RLCA
`define RLA opcode == 8'h17 // Specific Opcode for RLA
`define RRCA opcode == 8'h0F // Specific Opcode for RRCA
`define RRA opcode == 8'h1F // Specific Opcode for RRA


//HALT
`define HALT pla[95]    //HALT opcode