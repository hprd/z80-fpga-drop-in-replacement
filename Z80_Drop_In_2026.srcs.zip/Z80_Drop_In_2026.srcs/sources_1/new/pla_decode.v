`timescale 1ns / 1ps

module pla_decode
(
    input wire [6:0] prefix,
    input wire [7:0] opcode,
    output wire [104:0] pla
);
wire [14:0] pla_in;
assign pla_in = {prefix[6:0], opcode[7:0]};

assign pla[0] = ((pla_in & 15'b0000001_11110100) == 15'b0000001_10100000) ? 1'b1 : 1'b0;   // ldx/cpx/inx/outx brk
assign pla[1] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11011001) ? 1'b1 : 1'b0;   // exx
assign pla[2] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11101011) ? 1'b1 : 1'b0;   // ex de,hl
assign pla[3] = ((pla_in & 15'b0000100_11011111) == 15'b0000100_11011101) ? 1'b1 : 1'b0;   // IX/IY prefix
assign pla[5] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11111001) ? 1'b1 : 1'b0;   // ld sp,hl
assign pla[6] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11101001) ? 1'b1 : 1'b0;   // jp hl
assign pla[7] = ((pla_in & 15'b0000100_11001111) == 15'b0000100_00000001) ? 1'b1 : 1'b0;   // ld rr,nn
assign pla[8] = ((pla_in & 15'b0000100_11100111) == 15'b0000100_00000010) ? 1'b1 : 1'b0;   // ld (rr),a/a,(rr)
assign pla[9] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_00000011) ? 1'b1 : 1'b0;   // inc/dec rr
assign pla[10] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11100011) ? 1'b1 : 1'b0;   // ex (sp),hl
assign pla[11] = ((pla_in & 15'b0000001_11100111) == 15'b0000001_10100001) ? 1'b1 : 1'b0;   // cpi/cpir/cpd/cpdr
assign pla[12] = ((pla_in & 15'b0000001_11100111) == 15'b0000001_10100000) ? 1'b1 : 1'b0;   // ldi/ldir/ldd/lddr
assign pla[13] = ((pla_in & 15'b0000100_11001111) == 15'b0000100_00000010) ? 1'b1 : 1'b0;   // ld direction
assign pla[15] = ((pla_in & 15'b0000001_11110111) == 15'b0000001_01100111) ? 1'b1 : 1'b0;   // rrd/rld
assign pla[16] = ((pla_in & 15'b0000100_11001111) == 15'b0000100_11000101) ? 1'b1 : 1'b0;   // push rr
assign pla[17] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_00000110) ? 1'b1 : 1'b0;   // ld r,n
assign pla[20] = ((pla_in & 15'b0000001_11100111) == 15'b0000001_10100011) ? 1'b1 : 1'b0;   // outx/otxr
assign pla[21] = ((pla_in & 15'b0000001_11100111) == 15'b0000001_10100010) ? 1'b1 : 1'b0;   // inx/inxr
assign pla[23] = ((pla_in & 15'b0000100_11001011) == 15'b0000100_11000001) ? 1'b1 : 1'b0;   // push/pop
assign pla[24] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11001101) ? 1'b1 : 1'b0;   // call nn
assign pla[25] = ((pla_in & 15'b0000100_11100111) == 15'b0000100_00000111) ? 1'b1 : 1'b0;   // rlca/rla/rrca/rra
assign pla[26] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00010000) ? 1'b1 : 1'b0;   // djnz e
assign pla[27] = ((pla_in & 15'b0000001_11000110) == 15'b0000001_01000000) ? 1'b1 : 1'b0;   // in/out r,(c)
assign pla[28] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11010011) ? 1'b1 : 1'b0;   // out (n),a
assign pla[29] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11000011) ? 1'b1 : 1'b0;   // jp nn
assign pla[30] = ((pla_in & 15'b0000100_11110111) == 15'b0000100_00100010) ? 1'b1 : 1'b0;   // ld hl,(nn)/(nn),hl
assign pla[31] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000011) ? 1'b1 : 1'b0;   // ld rr,(nn)/(nn),rr
assign pla[33] = ((pla_in & 15'b0000001_11001111) == 15'b0000001_01000011) ? 1'b1 : 1'b0;   // ld direction
assign pla[34] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000001) ? 1'b1 : 1'b0;   // out (c),r
assign pla[35] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11001001) ? 1'b1 : 1'b0;   // ret
assign pla[37] = ((pla_in & 15'b0000100_11110111) == 15'b0000100_11010011) ? 1'b1 : 1'b0;   // out (n),a/a,(n)
assign pla[38] = ((pla_in & 15'b0000100_11110111) == 15'b0000100_00110010) ? 1'b1 : 1'b0;   // ld (nn),a/a,(nn)
assign pla[39] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00001000) ? 1'b1 : 1'b0;   // ex af,af'
assign pla[40] = ((pla_in & 15'b0100100_11111111) == 15'b0100100_00110110) ? 1'b1 : 1'b0;   // ld (ix+d),n
assign pla[42] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_11000100) ? 1'b1 : 1'b0;   // call cc,nn
assign pla[43] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_11000010) ? 1'b1 : 1'b0;   // jp cc,nn
assign pla[44] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11001011) ? 1'b1 : 1'b0;   // CB prefix
assign pla[45] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_11000000) ? 1'b1 : 1'b0;   // ret cc
assign pla[46] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000101) ? 1'b1 : 1'b0;   // reti/retn
assign pla[47] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00011000) ? 1'b1 : 1'b0;   // jr e
assign pla[48] = ((pla_in & 15'b0000100_11100111) == 15'b0000100_00100000) ? 1'b1 : 1'b0;   // jr ss,e
assign pla[49] = ((pla_in & 15'b0100000_11111111) == 15'b0100000_11001011) ? 1'b1 : 1'b0;   // CB prefix with IX/IY
assign pla[50] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00110110) ? 1'b1 : 1'b0;   // ld (hl),n
assign pla[51] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_11101101) ? 1'b1 : 1'b0;   // ED prefix
assign pla[52] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_10000110) ? 1'b1 : 1'b0;   // add/sub/and/or/xor/cp (hl)
assign pla[53] = ((pla_in & 15'b0000100_11111110) == 15'b0000100_00110100) ? 1'b1 : 1'b0;   // inc/dec (hl)
assign pla[55] = ((pla_in & 15'b0000010_00000111) == 15'b0000010_00000110) ? 1'b1 : 1'b0;   // Every CB op (hl)
assign pla[56] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_11000111) ? 1'b1 : 1'b0;   // rst p
assign pla[57] = ((pla_in & 15'b0000001_11110111) == 15'b0000001_01000111) ? 1'b1 : 1'b0;   // ld i,a/r,a
assign pla[58] = ((pla_in & 15'b0010100_11000111) == 15'b0010100_01000110) ? 1'b1 : 1'b0;   // ld r,(hl)
assign pla[59] = ((pla_in & 15'b0010100_11111000) == 15'b0010100_01110000) ? 1'b1 : 1'b0;   // ld (hl),r
assign pla[61] = ((pla_in & 15'b0000100_11000000) == 15'b0000100_01000000) ? 1'b1 : 1'b0;   // ld r,r'
assign pla[64] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_11000110) ? 1'b1 : 1'b0;   // add/sub/and/or/xor/cmp a,imm
assign pla[65] = ((pla_in & 15'b0000100_11000000) == 15'b0000100_10000000) ? 1'b1 : 1'b0;   // add/sub/and/or/xor/cmp a,r
assign pla[66] = ((pla_in & 15'b0000100_11000110) == 15'b0000100_00000100) ? 1'b1 : 1'b0;   // inc/dec r
assign pla[68] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000010) ? 1'b1 : 1'b0;   // adc/sbc hl,rr
assign pla[69] = ((pla_in & 15'b0000100_11001111) == 15'b0000100_00001001) ? 1'b1 : 1'b0;   // add hl,rr
assign pla[70] = ((pla_in & 15'b0000010_11000000) == 15'b0000010_00000000) ? 1'b1 : 1'b0;   // rlc r
assign pla[72] = ((pla_in & 15'b0000010_11000000) == 15'b0000010_01000000) ? 1'b1 : 1'b0;   // bit b,r
assign pla[73] = ((pla_in & 15'b0000010_11000000) == 15'b0000010_10000000) ? 1'b1 : 1'b0;   // res b,r
assign pla[74] = ((pla_in & 15'b0000010_11000000) == 15'b0000010_11000000) ? 1'b1 : 1'b0;   // set b,r
assign pla[75] = ((pla_in & 15'b0000100_11000111) == 15'b0000100_00000101) ? 1'b1 : 1'b0;   // dec r
assign pla[76] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00111000) ? 1'b1 : 1'b0;   // 111 (CP)
assign pla[77] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00100111) ? 1'b1 : 1'b0;   // daa
assign pla[78] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00010000) ? 1'b1 : 1'b0;   // 010 (SUB)
assign pla[79] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00011000) ? 1'b1 : 1'b0;   // 011 (SBC)
assign pla[80] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00001000) ? 1'b1 : 1'b0;   // 001 (ADC)
assign pla[81] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00101111) ? 1'b1 : 1'b0;   // cpl
assign pla[82] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000100) ? 1'b1 : 1'b0;   // neg
assign pla[83] = ((pla_in & 15'b0000001_11110111) == 15'b0000001_01010111) ? 1'b1 : 1'b0;   // ld a,i/a,r
assign pla[84] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00000000) ? 1'b1 : 1'b0;   // 000 (ADD)
assign pla[85] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00100000) ? 1'b1 : 1'b0;   // 100 (AND)
assign pla[86] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00110000) ? 1'b1 : 1'b0;   // 110 (OR)
assign pla[88] = ((pla_in & 15'b0001000_00111000) == 15'b0001000_00101000) ? 1'b1 : 1'b0;   // 101 (XOR)
assign pla[89] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00111111) ? 1'b1 : 1'b0;   // ccf
assign pla[91] = ((pla_in & 15'b0000001_11100110) == 15'b0000001_10100010) ? 1'b1 : 1'b0;   // inx/outx/inxr/otxr
assign pla[92] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_00110111) ? 1'b1 : 1'b0;   // scf
assign pla[95] = ((pla_in & 15'b0000100_11111111) == 15'b0000100_01110110) ? 1'b1 : 1'b0;   // halt
assign pla[96] = ((pla_in & 15'b0000001_11000111) == 15'b0000001_01000110) ? 1'b1 : 1'b0;   // im n
assign pla[97] = ((pla_in & 15'b0000100_11110111) == 15'b0000100_11110011) ? 1'b1 : 1'b0;   // di/ei
assign pla[99] = ((pla_in & 15'b0000000_00000001) == 15'b0000000_00000001) ? 1'b1 : 1'b0;   // opcode[0]
assign pla[100] = ((pla_in & 15'b0000000_00000010) == 15'b0000000_00000010) ? 1'b1 : 1'b0;   // opcode[1]
assign pla[101] = ((pla_in & 15'b0000000_00000100) == 15'b0000000_00000100) ? 1'b1 : 1'b0;   // opcode[2]
assign pla[102] = ((pla_in & 15'b0000000_00001000) == 15'b0000000_00001000) ? 1'b1 : 1'b0;   // opcode[3]
assign pla[103] = ((pla_in & 15'b0000000_00010000) == 15'b0000000_00010000) ? 1'b1 : 1'b0;   // opcode[4]
assign pla[104] = ((pla_in & 15'b0000000_00100000) == 15'b0000000_00100000) ? 1'b1 : 1'b0;   // opcode[5]

// Entries not used by timing matrix
assign pla[67] = 1'b0;   // in
assign pla[62] = 1'b0;   // For all CB opcodes
assign pla[54] = 1'b0;   // Every CB with IX/IY
assign pla[22] = 1'b0;   // CB prefix w/o IX/IY
assign pla[14] = 1'b0;   // dec rr
assign pla[4] = 1'b0;   // ld x,a/a,x

// Duplicate entries
assign pla[18] = 1'b0;   // ldi/ldir/ldd/lddr
assign pla[19] = 1'b0;   // cpi/cpir/cpd/cpdr
assign pla[32] = 1'b0;   // ld i,a/a,i/r,a/a,r
assign pla[36] = 1'b0;   // ld(rr),a/a,(rr)
assign pla[41] = 1'b0;   // IX/IY
assign pla[60] = 1'b0;   // rrd/rld
assign pla[63] = 1'b0;   // ld r,*
assign pla[71] = 1'b0;   // rlca/rla/rrca/rra
assign pla[87] = 1'b0;   // ld a,i / ld a,r
assign pla[90] = 1'b0;   // djnz *
assign pla[93] = 1'b0;   // cpi/cpir/cpd/cpdr
assign pla[94] = 1'b0;   // ldi/ldir/ldd/lddr
assign pla[98] = 1'b0;   // out (*),a/in a,(*)

endmodule
