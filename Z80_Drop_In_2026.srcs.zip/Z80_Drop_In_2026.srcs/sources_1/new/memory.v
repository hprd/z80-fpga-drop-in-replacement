`timescale 1ns / 1ps

module memory(
    input CLK_b,  
    input MREQ_b,     // logic low for if using mem
    input RD_b,       // logic low
    input WR_b,       // logic low
    input [15:0] ADDR,
    inout [7:0] DATA,
    input RESET_b
    );
    
    wire [7:0] DATA_OUT;

    // Drive the data bus ONLY during read cycles
    assign DATA = (!MREQ_b && !RD_b) ? DATA_OUT : 8'hZZ;

    blk_mem_gen_0 RAM (
        .clka (CLK_b),
        .addra(ADDR),
        .dina (DATA),        // write comes from bus
        .douta(DATA_OUT),
        .ena  (!MREQ_b),
        .wea  (!MREQ_b && !WR_b)
    );

    reg counter = 1'b0;
    assign clk_pos = counter;
    assign clk_neg = ~counter;

    always @(posedge CLK_b) begin
        if(RESET_b) counter = counter + 1;
    end
    
    
endmodule
